#ifndef _SEMANTIC_H_
#define _SEMANTIC_H_

static void insertNode(TreeNode* t);
void buildSymtab(TreeNode* raiz);

#endif