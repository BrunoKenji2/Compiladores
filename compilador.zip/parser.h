#ifndef _PARSER_H_
#define _PARSER_H_
#include "globals.h"
TreeNode *parse(void);
#endif